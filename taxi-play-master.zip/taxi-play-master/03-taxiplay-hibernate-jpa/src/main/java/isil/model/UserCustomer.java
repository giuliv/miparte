package isil.model;

import javax.persistence.*;
import javax.persistence.criteria.CriteriaBuilder;

@Entity
@Table
public class UserCustomer {

    @Id
    @Column(name = "usercustomer_id")
    private Integer id;

    @Column
    private String username;

    @OneToOne(mappedBy = "userCustomer", fetch = FetchType.LAZY)
    private Passenger passenger;

    public UserCustomer() {
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public Passenger getPassenger() {
        return passenger;
    }

    public void setPassenger(Passenger passenger) {
        this.passenger = passenger;
    }

    @Override
    public String toString() {
        return "UserCustomer{" +
                "id=" + id +
                ", username='" + username + '\'' +
                '}';
    }
}
