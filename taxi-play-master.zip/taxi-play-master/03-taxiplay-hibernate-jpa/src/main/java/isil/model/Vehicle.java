package isil.model;

import javax.persistence.*;

@Entity
@Table
public class Vehicle {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "vehicle_id")
    private Integer id;

    @Column
    private String license_plate;

    @Column
    private String brand;

    @Column
    private String model;

    @Column
    private String color;

    @Column
    private Integer capacity;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "driver_id")
    private Driver driver;

    public Vehicle() {
    }

    public Vehicle(String license_plate, String brand, String model, String color, Integer capacity, Driver driver) {
        this.license_plate = license_plate;
        this.brand = brand;
        this.model = model;
        this.color = color;
        this.capacity = capacity;
        this.driver = driver;
    }


    @Override
    public String toString() {
        return "Vehicle{" +
                "id=" + id +
                ", license_plate='" + license_plate + '\'' +
                ", brand='" + brand + '\'' +
                ", model='" + model + '\'' +
                ", color='" + color + '\'' +
                ", capacity=" + capacity +
                '}';
    }
}
