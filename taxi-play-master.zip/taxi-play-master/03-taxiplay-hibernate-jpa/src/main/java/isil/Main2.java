package isil;

import isil.model.Passenger;
import isil.model.UserCustomer;
import isil.service.PassengerService;

import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import java.util.List;

public class Main2 {

    public static void main(String[] args) {

        EntityManagerFactory emf = Persistence.createEntityManagerFactory("isilPU");


        /**** One to one  ****/

        UserCustomer userCustomer = new UserCustomer();
        userCustomer.setId(1);
        userCustomer.setUsername("uc001");



        Passenger passenger = new Passenger();
       // passenger.setId(1);
        passenger.setName("Hugo");
        passenger.setLast_name("Pérez");
        passenger.setPhone("987456123");
        passenger.setEmail("perez@isil.com");
        passenger.setPassword("123456");
        passenger.setUserCustomer(userCustomer);

        PassengerService passengerService = new PassengerService(emf);

        passengerService.create(passenger);

        List<Passenger> passengerList = passengerService.findAll();
        System.out.println("passenger List = "+passengerList);

       // UserCustomer userCustomer1 = new UserCustomer(emf);



//        authorService.delete(1000);
//        authorList = authorService.findAll();
//        System.out.println("authorList = " + authorList);

        /**** Address CRUD ****/

//        Address address = new Address();
//        address.setId(1);
//        address.setName("Av Benavides 1180");
//        address.setCity("Lima");
//        address.setCountry("Peru");

//        AddressService addressService = new AddressService(emf);
//        addressService.create(address);
//
//        List<Address> addressList = addressService.findAll();
//        System.out.println("addressList = " + addressList);
//
//        addressService.delete(1);
//        addressList = addressService.findAll();
//        System.out.println("addressList = " + addressList);
    }

}

