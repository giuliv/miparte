package isil.service;

import isil.model.UserCustomer;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import java.util.List;

public class UserCustomerService {


    private static EntityManager manager;

    public UserCustomerService(EntityManagerFactory emf) {
        manager = emf.createEntityManager();
    }

    public void create(UserCustomer userCustomer){
        manager.getTransaction().begin();
        manager.persist(userCustomer);
        manager.getTransaction().commit();
    }

    public void delete(Integer id){
        manager.getTransaction().begin();
        UserCustomer userCustomer = findById(id);
        if(userCustomer != null){
            manager.remove(userCustomer);
        }
        manager.getTransaction().commit();
    }

    public List<UserCustomer> findAll(){
        return (List<UserCustomer>) manager
                .createQuery("SELECT a FROM UserCustomer a ").getResultList();
    }

    public UserCustomer findById(Integer id){
        return manager.find(UserCustomer.class, id);
    }
}
