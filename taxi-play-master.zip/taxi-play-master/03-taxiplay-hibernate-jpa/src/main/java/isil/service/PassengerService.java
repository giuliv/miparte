package isil.service;

import isil.model.Passenger;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import java.util.List;

public class PassengerService {

    private static EntityManager manager;

    public PassengerService(EntityManagerFactory emf) {
        manager = emf.createEntityManager();
    }

    public void create(Passenger passenger){
        manager.getTransaction().begin();
        manager.persist(passenger);
        manager.getTransaction().commit();
    }

    public void delete(Integer id){
        manager.getTransaction().begin();
        Passenger passenger = findById(id);
        if(passenger != null){
            manager.remove(passenger);
        }
        manager.getTransaction().commit();
    }

    private Passenger findById(Integer id) {
        return manager.find(Passenger.class, id);
    }

    public List<Passenger> findAll(){
        return  (List<Passenger>) manager
                .createQuery("FROM Passenger").getResultList();
    }
}
