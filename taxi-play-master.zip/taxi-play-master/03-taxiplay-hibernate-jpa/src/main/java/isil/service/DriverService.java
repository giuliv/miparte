package isil.service;

import isil.model.Driver;


import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import java.util.List;

public class DriverService {

    private static EntityManager manager;

    public DriverService(EntityManagerFactory emf) {
        manager = emf.createEntityManager();
    }

    public void create(Driver driver){
        manager.getTransaction().begin();
        manager.persist(driver);
        manager.getTransaction().commit();
    }

    public void delete(Integer id){
        manager.getTransaction().begin();
        Driver driver = findById(id);
        if(driver != null){
            manager.remove(driver);
        }
        manager.getTransaction().commit();
    }

    private Driver findById(Integer id) {
        return manager.find(Driver.class, id);
    }

    public List<Driver> findAll(){
       return  (List<Driver>) manager
               .createQuery("FROM Driver").getResultList();
    }


}
