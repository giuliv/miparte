package isil;


import isil.model.Driver;
import isil.model.Vehicle;


import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import java.util.List;

public class Main {

    private static EntityManagerFactory emf = Persistence.
            createEntityManagerFactory("isilPU");

    public static void main(String[] args) {
        createDriver();
        listData();
    }

    private static void createDriver(){
        EntityManager em = emf.createEntityManager();
        em.getTransaction().begin();
        Driver driver1 = new Driver("Gustavo", "Torres","bla bla ","jose@isil.pe",null);
        em.persist(driver1);
        em.persist(new Vehicle("456-ASD","Suzuki","Celerio","Black",4, driver1));
        em.persist(new Vehicle("897-YHN","Toyota","Corolla","Green",4,driver1));
        em.getTransaction().commit();
        em.close();
    }

    private static void listData(){
        EntityManager em = emf.createEntityManager();
        Driver currentDriver = em.find(Driver.class, 1);
        System.out.println("current Driver = " + currentDriver);
        List<Vehicle> vehicles = currentDriver.getVehicles();
        for (Vehicle vehicle : vehicles) {
            System.out.println("* vehicle = " + vehicle);
        }
        em.close();
    }

}
