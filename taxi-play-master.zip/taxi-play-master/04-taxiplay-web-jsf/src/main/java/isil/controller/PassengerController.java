package isil.controller;

import isil.model.Passenger;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.RequestScoped;
import java.util.ArrayList;
import java.util.List;

@ManagedBean(name = "passengerController")
@RequestScoped
public class PassengerController {

    public List<Passenger> getPassengerList(){
        List<Passenger> passengerList = new ArrayList<>();

        Passenger p1 = new Passenger();
        p1.setId(1);
        p1.setName("Mery Villafranca");
        p1.setCity("Lima");
        p1.setCountry("Perú");

        passengerList.add(p1);

        Passenger p2 = new Passenger();
        p2.setId(2);
        p2.setName("Gabriela Gómez");
        p2.setCity("Guadalajara");
        p2.setCountry("México");

        passengerList.add(p2);

        return passengerList;
    }
}
