package com.isil;

public class Main {
    //    public static void main(String[]args){
//        DriverDAO driverDAO = new DriverDAO();
//        List<Driver>drivers = driverDAO.findAll();
//        for (Driver d: drivers) {
//            System.out.println("Núero : "+ d.getCorreo());
//        }
//    }
}
